package Controllers;

import Views.authView;

public class RunApp {
    public static void main(String[] args) {
        new authView().authView();
    }
}
