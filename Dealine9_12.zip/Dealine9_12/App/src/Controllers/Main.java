package Controllers;

import View.viewMain;

public class Main {
    public static void main(String[] args) {
        new viewMain();
    }
}
